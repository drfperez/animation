Pivot Animator

Version 5.2.5
11 / 01 / 2024

Created By: Peter Bone
Company: Motusoft GmbH
email: support@pivotanimator.net
Pivot website : http://www.pivotanimation.net
Pivot Facebook page : http://www.facebook.com/pivotanimatorofficial

Please report any bugs to the email shown above with a detailed description of the steps to reproduce the error.

A detailed user manual can be found at
http://pivotanimator.net/help5-2/index.htm


**********************************************************************

New features Since v4.2.8

Frame inbetweening
Bendy line segments
Canvas zoom
Virtual camera
Colour backgrounds
Gradient backgrounds
Text tool
Multiple colours per figure
Multiple sprites per figure
Much higher segment limit per figure (30,000)
Polyfill tool
Segment colour gradients
Figure outlines
Line segments with square ends
Ability to modify existing figure types
Faster graphics using the gpu
Antialiased drawing with subpixel accuracy
Status bar info at bottom of main window
Animated PNG export
WMV, WEBM, MP4 video export
STK figure file preview in Windows Explorer
Manual input for segment pose


**********************************************************************

Changes and fixes in v5.1.2

Bug fix. Running out of memory while exporting large animated gifs.
Bug fix. Selecting a polygon while adding polygon then delete gives error.
Bug fix. Click away from figure builder when screen fully transparent selects window underneath.
Bug fix. Joined figures sometimes not staying joined during tween.
Bug fix. Onion skins and transparent figures sometimes not drawn correctly.
Bug fix. Export as separate images working first time but not after.
Bug fix. Parts of other figures disappearing if figure dragged too fast.
Bug fix. Click a timeline frame while previewing another frame (Ctrl+P) gives error.
Bug fix. Missing parts when moving a thick bent line with square ends.
Bug fix. Can't get figure selector window on top again after selecting main window and re-clicking Add figure.

Spacebar shortcut for panning canvas using left mouse button. For those without a mouse wheel. 
Controls for copying and pasting virtual camera added to View menu (F11, F12).
Indication shown in figure builder window title when in edit mode.
Filled circles with thickness > 0 drawn as single object to avoid overlap when transparent.
Option added to figure builder View menu to highlight selected segment (F12) (like v4).
FFV1 lossless avi video export added to video export options.
Chinese language file updated for v5.

**********************************************************************

Changes and fixes in v5.1.3

Bug fix. Segment gradients not copied when segments are duplicated in figure builder.
Bug fix. Segment gradients not copied when nominate origin is used in figure builder.
Bug fix. Figures sometimes not selectable after adding tweened frames to timeline.
Bug fix. Prevent resizing figure builder window to nothing when in transparent mode.
Bug fix. Error when exporting due to log file creation in restricted folder.

STK file preview handler added so that STK files can be previewed from pivot load window or Windows Explorer.

**********************************************************************

Changes and fixes in v5.1.4

Bug fix: Error when exporting due to log file creation permissions.
Bug fix: Ctrl+R causes permanent edit mode even in main window.
Bug fix: Pressing arrow up in fps bar causes it to go down and visa versa.
Bug fix: Timeline frames sometimes remain after starting new animation.

Opacity value preserved when clicking colours in the colour selector.


**********************************************************************

Changes and fixes in v5.1.5

Bug fix: V-cam handles can't be dragged easily, especially when scale larger than animation.
Bug fix: Can add frame using space key while playing or previewing.
Bug fix: Modify figure not updating figures correctly if only segment length / bend changed.
Bug fix: Animation playing too slowly for most FPS values.
Bug fix: When adding a line/circle in builder, clicking the background first prevents line being seen while adding.
Bug fix: At the point where a polyfill start & end, outline has square ends when segments have thickness 0
Bug fix: Message boxes appear stuck behind main window if clicking another window while visible and clicking back.
Bug fix: Clicking the main window edit figure button while adding a polygon in the figure builder causes error.
Bug fix: With transparent backgrounds, areas outside animation area not cleared while playing or exporting.
Bug fix: Text object sometimes not correct with certain characters and fonts (e.g. 'tt' with Calibri).
Bug fix: Main window not selected after closing some other windows.
Bug fix: Colour sometimes changing after using colour picker in colour selector, if cursor over colour panel area.
Bug fix: Using Ctrl+D or Ctrl+V while dragging a figure causes drawing errors.
	
Enter key now closes window after naming a new figure type, text object or background without needing to click enter.
'Yes to All' and 'No to All' buttons added to the message asking to remove figure type when deleting multiple figures.

**********************************************************************

Changes and fixes in v5.1.6

Bug fix: Modify figure type and then undo in main window can cause problems.
Bug fix: Clicking a polygon in the builder while adding a new segment, duplicating or adding a sprite causes issues.

Polygons with bent lines. Click selection improved
Text editor preview now updates as you type (optional incase too slow)
Recent Animations listed in File menu
Full Arabic language translation (thanks to rara games)

**********************************************************************

Changes and fixes in v5.1.7

Bug fix: Update live preview option in text window is in front of font drop down box
Bug fix: Add frames and change dimensions in Options, click Yes in message box. No change.
Bug fix: Builder segment length text not updated when using ctrl or R with arrow keys to stretch segments.
Bug fix: Recent file list sometimes not updated after Save As.

**********************************************************************

Changes and fixes in v5.1.8

Bug fix: Angle of segments sometimes not in correct range (-180 to 180), leading to inbetweening errors
Bug fix: Timeline updating particularly slowly when dragging scrollbar to the left
Bug fix: Slow update when dragging the canvas or timeline scrollbars. Now much smoother
Bug fix: Frames with inbetween value of -1 not shown with a cross correctly sometimes
Bug fix: Mouse wheel canvas zoom changed to only work when cursor is within canvas area, not over other controls
Bug fix: Changing figure transparency by dragging bar and then undo only undoes a small amount, instead of restoring the value before dragging started
Bug fix: Exporting as gif sometimes gives wrong colours if first frame lacks some colours from subsequent frames
Bug fix: Copying frames and pasting into a new animation sets the frame rate to maximum instead of the copied value

New feature to locate figure handles to their position in the previous or next frame. Place the cursor over a handle and press the L key (Shift+L for next frame)
Blank area of figure builder window below the buttons can no longer be clicked when window is transparent
Pivot Classic font added, which looks like the alphabet figures but can be used in the text editor or in MS Word, etc
Path of selected segment to figure origin shown when selected segment highlighting is enabled in the figure builder
When adding a polygon in the figure builder, the initial colour is now based on the first segment handle clicked
Figure builder circle fill button now works with branches using the Shift key
Main window zoomable canvas area now increases size if v-cam positioned outside it
deformation_demo.piv included as an example of deforming objects using polyfill and inbetweening

**********************************************************************

Changes and fixes in v5.1.9

Bug fix: Copy and paste fish 🐟 unicode character into text editor gives error because cannot draw
Bug fix: Deleting all characters in text editor leaves one remaining in preview
Bug fix: Square end line segment click selection not correct


**********************************************************************

Changes and fixes in v5.1.10

Bug fix: Loading sprites. Sometimes white blocks where transparency should be
Bug fix: Access violation sometimes when 'highlight selected segment' is enabled in figure builder

V-cam couldn't be seen over a red background. Black outlines now used for all handles
R key handle repositioning now supports right mouse drag for bending


**********************************************************************

Changes and fixes in v5.1.11

Input segment values added for manual entering of segment geometry. Keyboard shortcut 'I'
Match zoom of main window canvas when clicking Edit to open figure builder


**********************************************************************

Changes and fixes in v5.1.12

Bug fix: Last edge of polygon doesn't follow bent lines
Bug fix: Timeline scroll bar movement with arrow keys doesn't update timeline
Bug fix: Clicking origin handle in builder selects polygon if behind handle
Bug fix attempt: Figure Builder window sometimes small when opened. Can't replicate, so fix may not work
Bug fix: Argument out of range in text editor when entering text with more than 255 different characters (such as long chinese paragraphs). More than 255 different characters is still not allowed, but it won't result in error
Bug partial fix: Exporting as gif with transparent background gives a glitch if a frame with transparency is followed by a frame with none. The partial fix places a transparent pixel in the bottom right hand corner.

Splitting a segment in the figure builder will now add the new node for any attached polygons
Message boxes no longer shown when export is completed or cancelled. Message shown on progress window instead
Download figures item added to Help menu. Links to the website's new STK library
Scale no longer reset when starting new figure in the figure builder (scroll is still reset)
Colour selector now remembers last clicked custom colour to make editing the list easier


**********************************************************************

Changes and fixes in v5.1.13

Bug fix: Transparency slider text doesn't line up when changing between frames
Bug fix: Figure Builder window sometimes small when first opened in transparent mode
Bug fix: Saving as Pivot 2 stk format in figure builder doesn't work


**********************************************************************

Changes and fixes in v5.1.14

Bug fix: Figure position status doesn't update after using center button
Bug fix: Some windows not staying in front after clicking another window and back
Bug fix: Custom colour gets reset after using colour picker in colour selector window
Bug fix: Right to left text (Arabic, Hebrew) doesn't come out right in text editor
Bug fix: First frame plays even when inbetweens set to -1

Option for resetting canvas zoom to 100% while playing. It will go back to the previous zoom when stopped
Resize option in Separate Image export changed to Height to match video export option
Loop play option stored when closing and re-opening the application


**********************************************************************

Changes and fixes in v5.1.15


Bug fix: Zoom in/out not right after playing and stopping animation (with reset zoom while playing enabled)

Colour selector will only update figure/segment transparency if the value was changed, making it possible to change colour of multiple selected figures/segments without altering their transparency (main window and figure builder)
Editing joined figures in the figure builder now takes into account transparency of the original figures


**********************************************************************

Changes and fixes in v5.1.16

Bug fix: Typing text into the text editor without clicking the text box first causes error when using Chinese language
Bug fix: Stk preview shows V2 for V3 files
Bug fix: Double clicking tool window title bars, such as the colour selector window, maximises them
Bug fix: Some controls look wrong in Windows 7, such as the text edit boxes in the colour editor

In the colour selector, you can now set a particular custom colour from the current colour by right clicking that custom colour.
Hold R and press L key now moves only the selected handle to the previous frame's position
Export as images file naming now matches Blender format using an underscore and at least 4 digits
Search feature in Figure or Background selector window
Rename feature in Figure or Background selector window. Click Rename button, then click a figure / background


**********************************************************************

Changes and fixes in v5.1.17

Bug fix: Export with all frames set to inbetweening of -1 gives error
Bug fix: Using R key with arrow keys. Raise arrow key and R key no longer down, so can't step in 1 pixel increments

Video export now supports Windows AVI, which is the same as the Pivot 4 AVI export, including compression for any codec you have installed.


**********************************************************************

Changes and fixes in v5.1.18

Bug fix: Figure types not correctly considered as single colour if they have invisible (zero thickness) segments of a different colour
Bug fix: End cap sometimes square when adding new line in builder. Should always be round
Bug fix: Cannot use I key to input camera values if there are no figures
Bug fix: Small issue with artifacts appearing sometimes when drawing highlighted path in figure builder
Bug fix: Export as SVG images sometimes not correct with gradient straight line segments
Bug fix: Export as SVG images sometimes not correct if regional windows settings use comma for decimal separator
Bug fix: Segment gradients lost when editing joined figures into a single figure
Bug fix: Setting center offset for radial gradient in background editor also affects linear gradient

Ability to quickly link polygons to multiple nodes. Start adding a polygon, click at least one node and then use Ctrl key while clicking another node. All nodes between the clicked and last clicked will be added.
Static segments always updated to edited pose when using Modify Figure type
Figure builder window now asks to overwrite unsaved changes when clicking the edit button in the main window
Line always visible when adding in builder even if thickness will be 0
Improvements to canvas scroll when fully zoomed out
Delete key no longer deletes frame after clicking a frame in the timeline. Ctrl+Alt+D still works for that.
Improvement to green inbetweening sliders, to make setting smaller values easier. Larger values can also be set.


**********************************************************************

Changes and fixes in v5.1.19

Bug fix: Some non latin languages not working correctly, such as Ukranian, Russian, Hebrew and Greek
Bug fix: Recent files list sometimes has duplicates after deleting files
Bug fix: SVG export of circles with diameter < thickness sometimes looks wrong

Disable mouse wheel zoom by setting 'MouseWheelZoom=0' in the pivot.ini settings file
Piv and stk files added to Windows recent file list when saved or loaded from Pivot
Main window menu item shortcuts no longer work while other windows are active
Inbetweens value is now stored immediately after editing the value in the box, if 1 frame is being edited


**********************************************************************

Changes and fixes in v5.1.20

Bug fix: Error message when setting inbetweens value of a frame sometimes


**********************************************************************

Changes and fixes in v5.1.21

Bug fix: Error message in figure builder sometimes with Add to animation, if segment order has changed
Bug fix: Figure sometimes drawn incorrectly after segment order changed and saved
Bug fix: Some animations freeze when loading due to large angles
Bug fix: STK preview images now showing correctly when figure contains long invisible segments
Bug fix: Text editor preview doesn't update when enabling/disabling Apply Gradient option


**********************************************************************

Changes and fixes in v5.1.22

Bug fix: Figure bounding rectangle sometimes not computed for joined figures (Selection and transparent figures issues)


**********************************************************************

Changes and fixes in v5.1.23

Bug fix: Outline disappears when using the nominate origin button in the figure builder
Bug fix: Outline thickness adjusted to figure scale when using Edit Joined Figures feature

Installer now saves demo animations and figures to program files. Pivot copies them to user Documents on first run. This prevents permissions issues
Option in pivot.ini settings file to change number of decimal places shown in info bars between 1 and 4 (InfoBarPrecision)


**********************************************************************

Changes and fixes in v5.1.24

Bug fix: Background onion skin is redrawn incorrectly after modify figure type, when first frame selected
Bug fix: Height in image export options has max 2160. Raised to 8000.
Bug fix: Figures sometimes positioned incorrectly if tweened with segment length / bend changes, added to timeline, saved and re-opened.
Bug fix attempt: Check that right clicked frame is valid before deleting to prevent errors

New option for creating a folder in separate image export options (selected by default)
New option for disabling smooth drawing (antialiasing) in Export options. Disabling will result in jagged edges, but solid colour.


**********************************************************************

Changes and fixes in v5.1.25

Bug fix: Some circles not drawn correctly when the segment length is 0 and scale is very large.
Bug fix: Figure Builder. Press I for segment input and type a value into Angle, then close before hitting enter. Gives error
Bug fix: Error messages when loading corrupted stk files with 0 segments. Will now just abort loading

Figures with long invisible lines (e.g. for sliding parts) now shown correctly in the figure selector window
Slight speedup to application startup
Links added for Pivot subreddit, Pivot discord server and Pivot YouTube channel in About box
System info shown in About box. Show this if you report a bug
Double click menu bar at top of figure builder to switch between fullscreen and restore, even when transparent


**********************************************************************

Changes and fixes in v5.1.26

Bug fix: Save file then rename folder and Save again, gives error because folder not found (piv & stk)
Bug fix: Zero length line segments with square ends don't rotate correctly

Stk files can now be dragged from Windows Explorer to the main window editing canvas
Smoother graphics when moving figures on the canvas (frame rate doubled)
Improvement to modify figure type logic for static segments, in the case where the segment connects to the origin
Delete figures in multiple selected frames, with matching IDs to the selected figures
Set figure colours in multiple selected frames, with matching IDs to the selected figures
Set figure transparency in multiple selected frames, with matching IDs to the selected figures
Set figure scale in multiple selected frames, with matching IDs to the selected figures (only when pressing Enter in the number box)
Raise / Lower selected figures in multiple selected frames, with matching IDs to the selected figures
Move figures in multiple selected frames, with matching IDs to the selected figures (translation by dragging orange handle only)
Join / unjoin in multiple selected frames, with matching IDs to the selected pair of figures 
Paste figures into multiple selected frames
Paste virtual camera into multiple selected frames


**********************************************************************

Changes and fixes in v5.1.27

Bug fix: Bend line and convert to circle. Handles are no longer at circle edge
Bug fix: Drag and drop, warning messages appear before drop is completed if figure already added
Bug fix: Scale figures in multiple frames can result in figures no longer in their joined positions
Bug fix: Access Violation error on startup for people who have not installed Windows 10 updates recently

Move camera in multiple selected frames, including rotation and scale
Improvement to scaling of figures in multiple frames to make it relative to existing figure scale in each frame
Add Frame button shows 'Update Frame' when editing a frame for less confusion. No change in functionality


**********************************************************************

Changes and fixes in v5.1.28

Bug fix: Fix to 5.1.27 where v-cam not inbetweened correctly when playing

Further improvement to figure drag smoothness


**********************************************************************

Changes and fixes in v5.1.29

Improved Font selector in the text editor window with auto-complete text input
Option in pivot.ini file to set selected frame highlighting colour (SelectedFrameColor)


**********************************************************************

Changes and fixes in v5.1.30

Bug fix: Access Violation sometimes when deleting multiple selected figures from multiple selected frames
Bug fix: Save As window in figure builder cleared of previous file name before opening
Bug fix: Paste Insert resets frame if working on a new frame. No need for it to

Match pan and zoom of main canvas with figure builder canvas when in transparent mode
Warning message (yes continue/no abort) shown when changes to a frame may be lost
Snapping of segment length improved to take into account canvas zoom


**********************************************************************

Changes and fixes in v5.1.31

Bug fix: Start Pivot with stk file when in match zoom transparent mode. Close figure builder and main window zoom is wrong.

Z-order added to the figure position manual input box. Also works with multiple selected figures
Scale box increment made smaller (0.1) when holding Shift key, for mouse wheel or horizontal dragging
Manual segment/figure position input boxes increments made smaller when holding the Shift key


**********************************************************************

Changes and fixes in v5.1.32

Bug: Access violation sometimes when selecting a background in background selector and choosing to remove background
Bug: Figure builder: Pressing enter when adding figure to animation and setting figure name with no text doesn't work
Bug: Double click to select a group of joined figures can happen when the clicks are on different figures
Bug: Error sometimes when using R key to move origin handle
Bug: Installer now makes sure that piv and stk files are associated to Pivot 5, even if Pivot 4 is still installed
Bug: Files overwritten without warning if exporting as separate images and not creating a new folder
Bug: Fix for scaling multiple figures where one contains long invisible segments

New feature in Edit menu to reset selected figures to default pose (the pose they were built with). Position and scale will be unchanged
L key figure alignment now moves all selected figures the same amount as the moved one
Center figure button now centers to the canvas view rather than the center of the animation area
Adding new figures now adds to the center of the canvas view
Improvement to how center and flip figure controls work with multiple selected figures if all joined in a single group
Copy and paste all values from manual value input window. Right click menu or Ctrl+Alt+C,Ctrl+Alt+V
Mouse wheel now scrolls through timeline when cursor is over it
Reset zoom while playing setting now defaults to off on first install
Fine canvas zooming using Shift key while rotating mouse wheel or using +/- keys (8 times slower). Main canvas and figure builder
Align virtual camera with current canvas pan/zoom added in View menu. Also works with multi-selected frames
Apply virtual camera transform to figures added in View menu. Also works with multi-selected frames
Center v-cam over selected figures. Also works with multi-selected frames
New multi frame action for add figure, including adding from figure builder or from file
New multi frame action for insert frame, for double framing, etc
Window size and position is preserved after restart for main window, figure builder, and figure and background selectors
Greek language file updates for v5


**********************************************************************

Changes and fixes in v5.1.33

Bug: Multiple figures with invisible segments. When first segment is invisible, scale them and can no longer move handle
Bug Fix Attempt: Sometimes access violation if green sliders are adjusted while playing

Segment bend snapping now scales with canvas zoom


**********************************************************************

Changes and fixes in v5.1.34

Bug: Main canvas sometimes not aligned correctly after using Create Figure Type in File menu and Match Canvas Zoom option
Bug: Copy and paste figure into another animation sometimes results in altered figure due to a similar figure existing with the same name 
Bug: Using L align key on a joined figure when the figure at the base of the joined tree isn't selected doesn't work
Bug: Figure and Background selector tool tip info can become wrong after deleting a figure type / background
Bug: With unsaved work, minimise main window and then try to close Pivot from the Taskbar. Can no longer be closed
Bug: Multiple frames can now be selected / deselected by using the <> keys while holding Shift or Ctrl (like in Pivot 4)

You can now step through frames using the <> keys while previewing without exiting preview mode
Smooth Sprites option added for export. The result is smoother when sprite objects are used
Timeline image quality improved when frame contains sprites
Using L+R keys to move handle to previous location. R can now be held down continuously while pressing L on multiple handles
Hand cursor is now shown when scroll dragging the canvas using the mouse wheel


**********************************************************************

Changes and fixes in v5.2.1

Bug: Cursor restoring to default when adding a segment in builder
Bug: Long text objects names shown in figure selector missing the first letter
Bug: Multiple copies of same figure type in figure selector after modifying a figure to remove outline and then copy and paste it
Bug: Figures joined to text objects not positioned correctly after modifying text object
Bug: Increment of scale box gets stuck on 0.1 if Alt+Shift used to resize figure
Bug: Sometimes a single text object character not rendered with gradient when previewing or exporting, if radial gradient background used
Bug: Export of figures with semi-transparent outlines not shown
Bug: Radial gradients not shown correctly in Background Color Window when first opened after starting Pivot
Bug: Out of memory or range check error sometimes when deleting a segment in the figure builder
Bug: Alt drag of figure in the figure builder gets stuck on after mouse is released if Alt key is released first
Bug: Modifying a flipped figure in the figure builder moves it to the top left corner of the animation

Dark mode option now available in Options, Preferences
Option to set the colour of the figure builder canvas in View menu (F9)
Select All Figures while holding Shift key selects all figures of same types as selected. Also works with Ctrl+Shift+A
Align segments to 45 degree angles using Shift key + arrow key combinations
Figure builder change line end cap can now be applied to branches. All lines in branch will have the same end cap
Delete a joint in the figure builder without moving other points by selecting the segment below the joint and deleting while holding the Ctrl key (undoes split segment)
Can now undo (Ctrl+Z) while selecting polygon handle connections in the Figure Builder
Can now Preview the figure without handles in the Figure Builder (View menu, Ctrl+P or space bar)
Reset v-cam (Ctrl+Alt+K) can now be applied to multiple frames
Colour button in the main window now shows the colour of the selected figure, if it's a single colour and only one figure is selected
Figure info in Status bar will show full figure type name as tool tip (hover cursor over it)
Sprite edit window: Coordinates and angle shown to help position handles
Duplicate figures (Ctrl+D) will now offset the figures based on current canvas zoom
C and V keys used in Segment Input window to copy / paste all values instead of Ctrl+Alt+C and Ctrl+Alt+V. Doesn't interfere with Windows shortcuts


**********************************************************************

Changes and fixes in v5.2.2

Bug: Ctrl+A doesn't select text in scale box when the cursor is there
Bug: Export as images. Clicking OK on 'image height is too large' message should not close the export options window
Bug: Pose of flipped figures not correct after modifying figure type, after reloading piv file
Bug: Holding Ctrl while aligning segments with Shift+arrow keys sets segment length to 1
Bug: Distorted figures sometimes after modifying type with multiple figures of the same type containing bends
Bug: Segment text in info bar not updated when using R key with arrow keys
Bug: Onion skins not always correct after applying action to multiple frames
Bug: Ctrl+C and Ctrl+V don't work in figure scale edit box
Bug: Figure transparency not kept for polygons when editing joined figures

New toolbar at top of canvas for figure positioning options, without needing keyboard shortcuts
Isolation positioning option to rotate only the segment and attached static segments. Caps Lock key or toolbar option
Can now select segments in the figure builder by clicking them anywhere, rather than only being able to click the handle
Can now adjust bends in main window using arrow keys or Shift+arrow keys (align) like you can in the figure builder
Can now align a segment using Shift+Arrow keys using R key (to alter only a single handle) or in the figure builder while Edit Mode is active
Now able to use Alt drag in figure builder while Edit Mode is active
Now able to apply thickness changes in figure builder segment input window to the branch (Shift+I). All segments will have the same thickness.
New multi-frame action for flip figures
Horizontal drag in number boxes (figure scale and segment input window) now selects text without changing the value. Mouse wheel still works for small changes (Shift key for even smaller). Vertical drag still works for large changes.
Improvement to modify figure to make segment angle changes only if changed in figure builder
Esc key now closes most windows, such as the segment input window (without storing changes)
Center Button now centers to animation (as in 5.1.x), but using Shift key centers to the view (as in 5.2.1)
Improvement to green inbetweening sliders. Click anywhere to set the value to that position
Shortcut for Modify figure in the figure builder window. Ctrl+U (Update figure)
Hold R key or enable Edit Mode in toolbar while joining figure to move the origin joint only
<> keys will loop over the animation frames when in preview mode and Loop option is enabled
When saving, a backup of the existing file will be kept in the same folder (to avoid losing work in case of issues while saving)
Can now switch between absolute and relative angle when inputting segment values. Popup menu or Ctrl+R


**********************************************************************

Changes and fixes in v5.2.3

Bug: Joined figures rotate as if in isolation mode when bending the segment they join to, even when isolation mode disabled
Bug: Polygons not made transparent when editing joined figures with figure transparency set
Bug: Sometimes cannot select figure containing a thick short bent line segment
Bug: Click add line or circle in figure builder and then immediately click add polygon. Then start clicking handles results in error
Bug: Isolated rotation not working correctly with segment input (I key) with static origin joined figures
Bug: Adding 0 thickness segment and selecting end point over polygon/sprite results in polygon/sprite being selected

Move figures or v-cam locked to horizontal or vertical using Ctrl key while dragging orange handle
Add line or circle or duplicate segment in the figure builder can now be aborted while adding by pressing the button again or using the keyboard shortcuts
Edit Mode now works while using input segment values (I key) by enabling the toolbar option or holding R while pressing I
Relative angle in segment input (I key) now takes into account joined figures when adjusting an origin segment
Segment alignment using Shift + arrow keys now works with figure rotation mode to place the handle relative to the figure origin
The backup file created when saving piv files is now given .bak extension (this is more standard). It can be loaded directly from Pivot (Open Animation, then choose file type)
Folder of last loaded sprite now stored. Default is Pictures if not yet stored
Folder of last loaded background image now stored. Default is Pictures if not yet stored


**********************************************************************

Changes and fixes in v5.2.4

Bug: Align using Edit mode. Moves the segment of the first figure regardless of figure the cursor is over


**********************************************************************

Changes and fixes in v5.2.5

Bug: Lines with square end caps can not be bent while in Edit Mode
Bug: Bend angle info not shown at bottom of main window for lines with square end caps
